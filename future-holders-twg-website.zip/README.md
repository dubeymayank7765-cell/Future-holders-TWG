# Future Holders TWG

## Is app ko free mein launch karne ke steps:

### 1. GitHub par account banao (kisi bade ki madad se)
- github.com par jao, sign up karo

### 2. Is folder ko GitHub par upload karo
- Naya repository banao (naam: future-holders-twg)
- Is poori folder ko upload kar do (GitHub Desktop app use karo, ya "upload files" wala option)

### 3. Vercel se connect karo (kisi bade ki madad se)
- vercel.com par jao
- "Continue with GitHub" se login karo
- Apna repository select karo
- "Deploy" dabao — bas, 1-2 minute mein live ho jayegi

### Local par test karne ke liye (optional, computer par):
```
npm install
npm run dev
```
